// Portfolio contents. Add your own school files later by editing the files arrays below.
const collections = [
  {
    name: "Activity",
    icon: "📁",
    description: "Class activities and exercises",
    files: [
      { name: "Activity 1 — Add your file", kind: "note", text: "This is a placeholder for your first IS104 activity. Upload your actual activity file and update this entry in script.js when you are ready." },
      { name: "Activity 2 — Add your file", kind: "note", text: "This is a placeholder for your second IS104 activity. Replace it with your actual activity." },
      { name: "Activity 3 — Add your file", kind: "note", text: "This is a placeholder for another class activity. Replace it with your actual activity." }
    ]
  },
  {
    name: "Projects",
    icon: "📁",
    description: "Projects and practical outputs",
    files: [
      { name: "Project 1 — Add your file", kind: "note", text: "This is a project placeholder. Add your actual project document, presentation, or other output." },
      { name: "Project 2 — Add your file", kind: "note", text: "This is another project placeholder. Replace it with your own work." }
    ]
  },
  {
    name: "Product Pitching",
    icon: "📁",
    description: "Product pitching presentation and materials",
    files: [
      { name: "Product Pitching — Add your file", kind: "note", text: "Upload your product pitching presentation or document and update this item to point to that file." }
    ]
  },
  {
    name: "Other Requirements",
    icon: "📁",
    description: "Other subject requirements and learning materials",
    files: [
      { name: "Other Requirement — Add your file", kind: "note", text: "Use this folder for additional IS104 requirements, certificates, reflections, or supporting documents." }
    ]
  }
];

const el = id => document.getElementById(id);
const folderGrid = el("folderGrid"), filePanel = el("filePanel"), preview = el("preview");
let activeFolder = 0;

function showFolders() {
  folderGrid.classList.remove("hidden");
  filePanel.classList.add("hidden");
  preview.classList.add("hidden");
  el("breadcrumb").textContent = "⌂ Home";
}
function openFolder(index) {
  activeFolder = index;
  const folder = collections[index];
  folderGrid.classList.add("hidden");
  filePanel.classList.remove("hidden");
  preview.classList.add("hidden");
  el("breadcrumb").textContent = "⌂ Home  /  " + folder.name;
  el("folderName").textContent = folder.name;
  const grid = el("fileGrid");
  grid.innerHTML = "";
  folder.files.forEach((file, fileIndex) => {
    const btn = document.createElement("button");
    btn.className = "file-entry";
    const symbol = file.kind === "pdf" ? "📕" : file.kind === "image" ? "🖼️" : file.kind === "video" ? "🎬" : "📄";
    btn.innerHTML = `<span class="file-symbol">${symbol}</span><span>${file.name}</span>`;
    btn.addEventListener("click", () => openFile(file));
    grid.appendChild(btn);
  });
}
function openFile(file) {
  filePanel.classList.add("hidden");
  preview.classList.remove("hidden");
  el("previewTitle").textContent = file.name;
  const body = el("previewBody");
  body.innerHTML = "";
  if (file.kind === "pdf") {
    const frame = document.createElement("iframe"); frame.src = file.url; frame.title = file.name; body.appendChild(frame);
  } else if (file.kind === "image") {
    const img = document.createElement("img"); img.src = file.url; img.alt = file.name; body.appendChild(img);
  } else if (file.kind === "video") {
    const video = document.createElement("video"); video.src = file.url; video.controls = true; body.appendChild(video);
  } else {
    const p = document.createElement("p"); p.textContent = file.text || "Add your file details here."; body.appendChild(p);
  }
}
collections.forEach((folder, index) => {
  const card = document.createElement("button");
  card.className = "folder-card";
  card.innerHTML = `<div class="folder-art">${folder.icon}</div><div class="folder-meta"><strong>${folder.name}</strong><span>${folder.files.length} items</span></div>`;
  card.addEventListener("click", () => openFolder(index));
  folderGrid.appendChild(card);
});
el("backFolders").addEventListener("click", showFolders);
el("backFiles").addEventListener("click", () => { preview.classList.add("hidden"); filePanel.classList.remove("hidden"); });
